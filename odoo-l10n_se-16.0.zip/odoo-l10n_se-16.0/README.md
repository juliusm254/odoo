# odoo-l10n_se
Swedish accounting. 4

Testa webhook2
Important! // Viktigt! <br>
Read to install!<br>
https://vertel.se/bokforing/installera-l10n-se

<b>After `sudo update` with a new nightly version of Odoo:</b> <br>
sudo rm -rf /usr/share/core-odoo/addons/l10n_se <br>
sudo rm -rf /usr/share/core-odoo/addons/l10n_se_ocr <br>



Module | Description
--- | --- 
account_change_plan 	|
l10n_se 	|
l10n_se_account_bank_statement_import 	|
l10n_se_account_payment_order 	|
l10n_se_bank | Basemodule for bank-drivers
l10n_se_bgmax |	Bankgirocentralen
l10n_se_budget |	
l10n_se_dibs | reconcile DIBS-transactions
l10n_se_hr_expense | 	
l10n_se_intrastat |	
l10n_se_izettle |	reconcile iZettle-transactions
l10n_se_klarna 	| reconsile Klarna-transactions
l10n_se_nordbanken | (not complete)
l10n_se_paypal 	| reconsile Paypal-transactions
l10n_se_purchase_products |	
l10n_se_seb 	| reconsile SEB-accounts
l10n_se_sie 	| SIE-import/export
l10n_se_skv 	|
l10n_se_swedbank | reconcile Swedbank-accounts
l10n_se_tax_report | Moms- and Agd-report, depends on report_glabels (odoo-report)
l10n_se_yearend_report | SRU-report
